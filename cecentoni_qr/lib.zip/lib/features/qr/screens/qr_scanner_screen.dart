import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:gap/gap.dart';
import '../providers/qr_provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_routes.dart';
import '../../../core/constants/app_strings.dart';

/// Pantalla de escaneo QR usando la cámara del teléfono.
///
/// Usa el paquete mobile_scanner que es el más moderno y
/// compatible con Flutter 3+ en iOS y Android.
///
/// Flujo:
/// 1. Se abre la cámara automáticamente
/// 2. Cuando detecta un QR, llama a qrScannerNotifier.procesarQr()
/// 3. Si el parseo es exitoso → navega a la pantalla de resultado
/// 4. Si hay error → muestra el error en pantalla
class QrScannerScreen extends ConsumerStatefulWidget {
  const QrScannerScreen({super.key});

  @override
  ConsumerState<QrScannerScreen> createState() => _QrScannerScreenState();
}

class _QrScannerScreenState extends ConsumerState<QrScannerScreen> {
  late MobileScannerController _cameraController;
  bool _navigating = false; // Evitar navegación múltiple

  @override
  void initState() {
    super.initState();
    _cameraController = MobileScannerController(
      facing: CameraFacing.back,
      detectionSpeed: DetectionSpeed.noDuplicates, // Solo procesa 1 QR
    );
    // Reiniciar el estado del provider al abrir la pantalla
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(qrScannerProvider.notifier).reiniciar();
    });
  }

  @override
  void dispose() {
    _cameraController.dispose();
    super.dispose();
  }

  void _onQrDetected(BarcodeCapture capture) {
    if (_navigating) return;

    final barcode = capture.barcodes.firstOrNull;
    if (barcode == null || barcode.rawValue == null) return;

    final rawData = barcode.rawValue!;
    ref.read(qrScannerProvider.notifier).procesarQr(rawData);
  }

  @override
  Widget build(BuildContext context) {
    // Escuchar cambios del estado del QR
    ref.listen<QrScannerState>(qrScannerProvider, (prev, next) {
      if (next.scanned && !_navigating) {
        _navigating = true;
        _cameraController.stop();

        if (next.producto != null) {
          // QR válido → ir a resultado
          context.push(AppRoutes.resultado);
        } else {
          // QR inválido → mostrar error y permitir reintentar
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(next.errorMessage ?? AppStrings.qrInvalido),
              backgroundColor: AppColors.error,
              behavior: SnackBarBehavior.floating,
              action: SnackBarAction(
                label: 'Reintentar',
                textColor: Colors.white,
                onPressed: () {
                  _navigating = false;
                  ref.read(qrScannerProvider.notifier).reiniciar();
                  _cameraController.start();
                },
              ),
            ),
          );
          _navigating = false;
        }
      }
    });

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text(AppStrings.escanearQR),
        actions: [
          // Linterna
          IconButton(
            icon: const Icon(Icons.flashlight_on),
            onPressed: () => _cameraController.toggleTorch(),
          ),
          // Girar cámara
          IconButton(
            icon: const Icon(Icons.flip_camera_ios),
            onPressed: () => _cameraController.switchCamera(),
          ),
        ],
      ),
      body: Stack(
        children: [
          // ── Cámara ──────────────────────────────────────────────────────
          MobileScanner(
            controller: _cameraController,
            onDetect: _onQrDetected,
          ),

          // ── Overlay con marco de escaneo ─────────────────────────────────
          CustomPaint(
            painter: _ScannerOverlayPainter(),
            child: Container(),
          ),

          // ── Instrucciones ────────────────────────────────────────────────
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [
                    Colors.black.withOpacity(0.85),
                    Colors.transparent,
                  ],
                ),
              ),
              child: Column(
                children: [
                  const Icon(
                    Icons.qr_code_2,
                    color: Colors.white,
                    size: 36,
                  ),
                  const Gap(8),
                  const Text(
                    AppStrings.apuntaCamara,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const Gap(20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Pintador del overlay de escaneo (marco con esquinas)
class _ScannerOverlayPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black54
      ..style = PaintingStyle.fill;

    // Tamaño del marco de escaneo
    const scanSize = 260.0;
    final left = (size.width - scanSize) / 2;
    final top = (size.height - scanSize) / 2 - 40;
    final right = left + scanSize;
    final bottom = top + scanSize;
    final scanRect = Rect.fromLTRB(left, top, right, bottom);

    // Oscurecer el área fuera del marco
    final path = Path()
      ..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
      ..addRRect(RRect.fromRectAndRadius(scanRect, const Radius.circular(12)))
      ..fillType = PathFillType.evenOdd;

    canvas.drawPath(path, paint);

    // Dibujar el marco del QR
    const cornerLength = 28.0;
    const cornerRadius = 4.0;
    const strokeWidth = 3.5;

    final cornerPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    // Esquina superior izquierda
    canvas.drawPath(
      Path()
        ..moveTo(left, top + cornerLength)
        ..lineTo(left, top + cornerRadius)
        ..arcToPoint(Offset(left + cornerRadius, top),
            radius: const Radius.circular(cornerRadius))
        ..lineTo(left + cornerLength, top),
      cornerPaint,
    );
    // Esquina superior derecha
    canvas.drawPath(
      Path()
        ..moveTo(right - cornerLength, top)
        ..lineTo(right - cornerRadius, top)
        ..arcToPoint(Offset(right, top + cornerRadius),
            radius: const Radius.circular(cornerRadius))
        ..lineTo(right, top + cornerLength),
      cornerPaint,
    );
    // Esquina inferior izquierda
    canvas.drawPath(
      Path()
        ..moveTo(left, bottom - cornerLength)
        ..lineTo(left, bottom - cornerRadius)
        ..arcToPoint(Offset(left + cornerRadius, bottom),
            radius: const Radius.circular(cornerRadius))
        ..lineTo(left + cornerLength, bottom),
      cornerPaint,
    );
    // Esquina inferior derecha
    canvas.drawPath(
      Path()
        ..moveTo(right - cornerLength, bottom)
        ..lineTo(right - cornerRadius, bottom)
        ..arcToPoint(Offset(right, bottom - cornerRadius),
            radius: const Radius.circular(cornerRadius))
        ..lineTo(right, bottom - cornerLength),
      cornerPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}