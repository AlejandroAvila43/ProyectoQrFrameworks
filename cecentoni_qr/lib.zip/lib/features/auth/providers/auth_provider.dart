import 'package:cecentoni_qr/core/errors/app_exceptions.dart';
import 'package:cecentoni_qr/models/usuario_model.dart';
import 'package:cecentoni_qr/services/auth_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';

// ── Providers de servicios ───────────────────────────────────────────────────

final authServiceProvider = Provider<AuthService>((ref) => AuthService());

// ── Estado del Auth ──────────────────────────────────────────────────────────

final authStateProvider = StreamProvider<User?>((ref) {
  return ref.watch(authServiceProvider).authStateChanges;
});

final currentUserProvider = FutureProvider<UsuarioModel?>((ref) async {
  final authState = ref.watch(authStateProvider);
  return authState.when(
    data: (user) async {
      if (user == null) return null;
      return ref.read(authServiceProvider).getCurrentUserData();
    },
    loading: () => null,
    error: (_, __) => null,
  );
});

// ── State para Login ────────────────────────────────────────────────────────

class LoginState {
  final bool isLoading;
  final String? errorMessage;
  final UsuarioModel? usuario;

  const LoginState({
    this.isLoading = false,
    this.errorMessage,
    this.usuario,
  });

  LoginState copyWith({
    bool? isLoading,
    String? errorMessage,
    UsuarioModel? usuario,
  }) {
    return LoginState(
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage,
      usuario: usuario ?? this.usuario,
    );
  }
}

class LoginNotifier extends StateNotifier<LoginState> {
  final AuthService _authService;

  LoginNotifier(this._authService) : super(const LoginState());

  Future<void> login({
    required String email,
    required String password,
  }) async {
    state = state.copyWith(isLoading: true, errorMessage: null);

    try {
      final usuario = await _authService.login(
        email: email,
        password: password,
      );
      state = state.copyWith(isLoading: false, usuario: usuario);
    } on AuthException catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.message);
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Error inesperado. Intenta de nuevo.',
      );
    }
  }

  Future<void> logout() async {
    await _authService.logout();
    state = const LoginState();
  }

  void limpiarError() {
    state = state.copyWith(errorMessage: null);
  }
}

final loginProvider = StateNotifierProvider<LoginNotifier, LoginState>((ref) {
  return LoginNotifier(ref.watch(authServiceProvider));
});
